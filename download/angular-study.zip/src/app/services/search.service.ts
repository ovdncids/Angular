import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import { MembersService } from './members.service';
import axios from 'axios';

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  constructor(
    private commonService: CommonService,
    private membersService: MembersService
  ) { }
  
  searchRead(q: string) {
    const url = 'http://localhost:3100/api/v1/search?q=' + q;
    axios.get(url).then((response) => {
      console.log('Done searchRead', response);
      this.membersService.members = response.data.members;
    }).catch((error) => {
      this.commonService.axiosError(error);
    });
  }
}
