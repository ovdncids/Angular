import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import axios from 'axios';

export interface Member {
  name: string
  age: string | number
}

@Injectable({
  providedIn: 'root'
})
export class MembersService {
  constructor(private commonService: CommonService) {}

  members: Member[] = [];
  member: Member = {
    name: '',
    age: ''
  };

  membersCreate(member: Member) {
    axios.post('http://localhost:3100/api/v1/members', member).then((response) => {
      console.log('Done membersCreate', response);
      this.membersRead();
    }).catch((error) => {
      this.commonService.axiosError(error);
    });
  }

  membersRead() {
    axios.get('http://localhost:3100/api/v1/members').then((response) => {
      console.log('Done membersRead', response);
      this.members = response.data.members;
    }).catch((error) => {
      this.commonService.axiosError(error);
    });
  }

  membersDelete(index: number) {
    axios.delete('http://localhost:3100/api/v1/members/' + index).then((response) => {
      console.log('Done membersDelete', response);
      this.membersRead();
    }).catch((error) => {
      this.commonService.axiosError(error);
    });
  }

  membersUpdate(index: number, member: Member) {
    axios.patch('http://localhost:3100/api/v1/members/' + index, member).then((response) => {
      console.log('Done membersUpdate', response);
      this.membersRead();
    }).catch((error) => {
      this.commonService.axiosError(error);
    });
  }
}
